/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package topic_2_linkedlist_int;

/**
 *
 * @author ITLAB1-PC24-STUDENT
 */
public class Node {
      	int data;  
    Node next;  

    // Constructor
    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

